public class CarPolyChallenge {

    private boolean engine = true;
    private int cylinders;
    private String name;
    private int wheels = 4;

    public CarPolyChallenge(int cylinders, String name) {
        this.cylinders = cylinders;
        this.name = name;
    }

    public void startEngine(){
        System.out.println("Car -> Car's engine is starting");
    }

    public void accelerate(){
        System.out.println("Car -> Car is accelerating");
    }

    public void brake(){
        System.out.println("Car ->Car is breaking");
    }

    public int getCylinders() {
        return cylinders;
    }

    public String getName() {
        return name;
    }
}

class Mitsubishi extends CarPolyChallenge{

    public Mitsubishi(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public void startEngine() {
        System.out.println("Mitsubishi -> Mitsubishi's engine is starting");
    }

    @Override
    public void accelerate() {
        System.out.println("Mitsubishi -> Mitsubishi is accelerating");
    }

    @Override
    public void brake() {
        System.out.println("Mitsubishi ->Mitsubishi is breaking");
    }
}

class Holden extends CarPolyChallenge{

    public Holden(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public void startEngine() {
        System.out.println("Holden -> Holden's engine is starting");
    }

    @Override
    public void accelerate() {
        System.out.println("Holden -> Holden is accelerating");
    }

    @Override
    public void brake() {
        System.out.println("Holden -> Holden is breaking");
    }
}

class Ford extends CarPolyChallenge{

    public Ford(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public void startEngine() {
        System.out.println("Ford -> Ford's engine is starting");
    }

    @Override
    public void accelerate() {
        System.out.println("Ford -> Ford is accelerating");
    }

    @Override
    public void brake() {
        System.out.println("Ford -> Ford is breaking");
    }
}
