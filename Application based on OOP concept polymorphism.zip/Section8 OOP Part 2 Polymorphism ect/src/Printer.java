public class Printer {
    private int tonerLevel;
    private int pagesPrinted;
    private boolean duplex;

    public Printer(int tonerLevel, boolean duplex) {
        this.pagesPrinted = 0;
        this.tonerLevel = (tonerLevel >= 0 && tonerLevel <= 100) ? tonerLevel : -1;
        this.duplex = duplex;
    }

    public int addToner(int tonerAmount) {
        int temp = this.tonerLevel + tonerAmount;
        if(temp < 101){
            if(temp > 0){
                return temp;
            }
        }else {
            return -1; }
        return -1;




        /* if (temp <= 100 || temp > 0) {
            System.out.println("Toner amount is123 " + tonerLevel);
            return temp; }
        else {
            System.out.println("Toner amount is " + tonerLevel + " So we return -1");
            return -1; }
    }*/
    }

    public int printPages(int pages){
        int jobPages = (duplex) ? (pages / 2) + (pages % 2) : pages;
        pagesPrinted += jobPages;
        return jobPages;
    }

    public int printPages1(int pagesToPrint){
        if (duplex) {
            System.out.println("Printer is a duplex");
            pagesPrinted = (int) Math.ceil(pagesToPrint / 2);
            System.out.println("Pages used = " + pagesPrinted);
            return pagesPrinted;
        }else {
           System.out.println("Printer is a simplex");
           pagesPrinted = pagesToPrint;
           System.out.println("Pages used = " + pagesPrinted);
            return pagesToPrint;
        }
    }

    public int getPagesPrinted() {
        return pagesPrinted;
    }
}
