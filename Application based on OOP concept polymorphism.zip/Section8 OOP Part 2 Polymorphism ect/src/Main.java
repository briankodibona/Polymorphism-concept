public class Main {
    public static void main(String[] args) {
     /*   ComputerCase theCase = new ComputerCase("2208", "Dell",
        "240");

        Monitor theMonitor = new Monitor("27 inch Beast", "Acer",
                27, "2540 x 1440");

        Motherboard theMotherboard = new Motherboard("BJ-200", "Asus",
                4,6,"v2.44");

        PersonalComputer thePC = new PersonalComputer("2208", "Dell",
                theMonitor, theMotherboard, theCase);

*//*        thePC.getMonitor().drawPixel(10,10,"Red");
        thePC.getMotherboard().loadProgram("IntelliJ");
        thePC.getComputerCase().pressPowerButton();*//*

        thePC.powerUp();
*/

        /*PlayerNonEncapsulated player = new PlayerNonEncapsulated();
        player.fullName = "Tim";
        player.health = 20;
        player.weapon = "Sword";

        int damage = 10;
        player.loseHealth(damage);
        System.out.println("Remaining health = " + player.healthRemaining());

        player.health = 200;
        player.loseHealth(11);
        System.out.println("Remaining health = " + player.healthRemaining());
*/
        /*PlayerEncapsulated player = new PlayerEncapsulated("Tim", 200, "Sword");
        System.out.println("Health = " + player.healthRemaining());*/

        /*Printer printer = new Printer( 75, false);
        printer.printPages(50);
        System.out.println("Printed = " + printer.getPagesPrinted());
        printer.addToner(75);*/
/*
        Movie movie = new Adventure("Star Wars");
        movie.watchMovie();*/

        /*Movie theMovie = Movie.getMovie("Science", "Star Wars");
        theMovie.watchMovie();*/
        /*Scanner s = new Scanner(System.in);
        while(true){
            System.out.println("Enter type (A , C, S or Q to quit");
            String type = s.nextLine();

            if ("Qq".contains(type)) {
                break;
            }

            System.out.println("Enter move title: ");
            String title = s.nextLine();
            Movie movie = Movie.getMovie(type,title);
            movie.watchMovie();*/

            Car porsche = new GasPoweredCar("Posche 911", 250.50, 6, 256, 36.5);
            porsche.startEngine();
            porsche.drive();

            var chef = new Car("Porsche");
            chef.startEngine();

            System.out.println("Class instance: " +  porsche.getClass().getSimpleName());

        }
    }

