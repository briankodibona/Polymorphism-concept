public class  Car {
    private String description;

    public Car(String description) {
        this.description = description;
    }

    public void startEngine(){
        System.out.println("Car -> startEngine");
    }

    protected void runEngine(){
        System.out.println("Car -> runEngine");
    }

    public void drive(){
        System.out.println("Car -> drive, type is " + getClass().getSimpleName());
        runEngine();
    }
}

class GasPoweredCar extends Car{
    private double avgKmPerLitre;
    private int cylinders = 6;
    private double topSpeed;

    private double gasInTank;

    public GasPoweredCar(String description) {
        super(description);
    }

    public GasPoweredCar(String description, double avgKmPerLitre
            , int cylinders, double topSpeed, double gasInTank) {
        super(description);
        this.avgKmPerLitre = avgKmPerLitre;
        this.cylinders = cylinders;
        this.topSpeed = topSpeed;
        this.gasInTank = gasInTank;
    }

    @Override
    public void startEngine() {
        System.out.printf("Gas -> Cylinders are firing %d %n" , cylinders);
        System.out.println(gasInTank + "L");
    }

    @Override
    protected void runEngine() {
        System.out.printf("Gas -> usage exceds the average: %.2f %n", avgKmPerLitre);
    }
}

class ElectricCar extends Car{
    private double avgKmPerCharge;
    private int batterySize = 6;
    private double topSpeed;


    public ElectricCar(String description) {
        super(description);
    }

    public ElectricCar(String description, double avgKmPerCharge
            , int batterySize, double topSpeed) {
        super(description);
        this.avgKmPerCharge = avgKmPerCharge;
        this.batterySize = batterySize;
        this.topSpeed = topSpeed;

    }

    @Override
    public void startEngine() {
        System.out.printf("BEV -> switch %d kWh battery on, Ready!%n",batterySize);

    }

    @Override
    protected void runEngine() {

        System.out.printf("BEV -> usage under the average: %.2f %n", avgKmPerCharge);
    }
}

class HybridCar extends Car{
    private double avgKmPerLitre;
    private int cylinders = 6;
    private int batterySize;
    private double topSpeed;

    private double gasInTank;

    public HybridCar(String description) {
        super(description);
    }

    public HybridCar(String description, double avgKmPerLitre
            , int cylinders, double topSpeed, double gasInTank, int batterySize) {
        super(description);
        this.avgKmPerLitre = avgKmPerLitre;
        this.cylinders = cylinders;
        this.topSpeed = topSpeed;
        this.gasInTank = gasInTank;
        this.batterySize = batterySize;
    }

    @Override
    public void startEngine() {
       System.out.printf("Hybrid -> %d cylinders are fired up.%n", cylinders);
       System.out.printf("Hybrid -> switch %d kWh battery on, Ready!%n", batterySize);
    }

    @Override
    protected void runEngine() {
       System.out.printf("Hybrid -> usage below average: %.2f %n", avgKmPerLitre);
    }
}





/*
class ElectricCar1 extends Car{
    private double avgKmPerCharge;
    private int batterySize;
    private double timeFor0to60;

    public ElectricCar1(String description, double avgKmPerCharge,
                       int batterySize, double timeFor0to60) {
        super(description);
        this.avgKmPerCharge = avgKmPerCharge;
        this.batterySize = batterySize;
        this.timeFor0to60 = timeFor0to60;
    }

    @Override
    public void startEngine() {
        System.out.println("You unplug your car from the charge port");
        super.startEngine();
    }

    @Override
    public void drive() {
        super.drive();
        System.out.println("You decide to check your avg millage");
        System.out.println("Avg Km per charge = :" + avgKmPerCharge);
    }
}




class HybridCar1 extends Car{
    private double avgKmPerLitre;
    private int batterySize;
    private int cylinders;
    private int totalRange;

    public HybridCar1(String description, double avgKmPerLitre,
                     int batterySize, int cylinders,
                     int totalRange) {
        super(description);
        this.avgKmPerLitre = avgKmPerLitre;
        this.batterySize = batterySize;
        this.cylinders = cylinders;
        this.totalRange = totalRange;
    }

    @Override
    public void startEngine() {
        System.out.println("Unplug and see you need to hit up the garage");
        super.startEngine();
    }

    @Override
    public void drive() {
        super.drive();
        System.out.println("You forgot to stop at the nearest garage and the dash displays");
        System.out.println("Fuel remaining: " + totalRange);

    }
}
*/
